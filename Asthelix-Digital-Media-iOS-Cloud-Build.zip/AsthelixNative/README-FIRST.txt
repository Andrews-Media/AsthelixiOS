ASTHELIX DIGITAL MEDIA — NATIVE iOS PROJECT

This is a SwiftUI Xcode project that packages your website inside an iPhone app.
It is not yet a signed, installable iPhone app.

FILES
- AsthelixDigitalMedia.xcodeproj/ — native iOS project
- AsthelixDigitalMedia/ — SwiftUI app source and bundled website
- codemagic.yaml — cloud build configuration (unsigned build check)

IMPORTANT
The included Codemagic workflow checks that the project builds, but produces an UNSIGNED app. An unsigned build cannot be installed on your iPhone. For private installation, you will need Apple code signing and an appropriate distribution method, such as TestFlight. That generally requires an Apple Developer Program membership and App Store Connect setup. If you are under the age required to enroll, ask a parent/guardian to help with the account setup.

PHONE-ONLY START
1. Download and extract the ZIP in the iPhone Files app.
2. Create a PRIVATE repository on GitHub using Safari.
3. Upload the extracted project files and folders into the repository, keeping the same folder structure (including codemagic.yaml at the repository root).
4. Create/sign in to Codemagic in Safari and connect the private GitHub repository.
5. Choose the workflow `asthelix-ios-unsigned` and start a build.
6. If it succeeds, you have confirmed the project builds. To install it, set up Apple signing and a private distribution route such as TestFlight; this unsigned workflow alone does not install the app.

Keep your GitHub repository private. Never share your Apple password, recovery code, or signing private keys in chat.
